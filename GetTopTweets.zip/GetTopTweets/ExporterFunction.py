# -*- coding: utf-8 -*-
import sys,getopt,datetime,codecs
if sys.version_info[0] < 3:
    import got
else:
    import got3 as got

def exporter(keyword,start,end,maxtweets):

	try:
		tweetCriteria = got.manager.TweetCriteria()
		outputFileName = "output_got.csv"

		tweetCriteria.querySearch = keyword
		tweetCriteria.since = start
		tweetCriteria.until = end
		tweetCriteria.topTweets = True
		tweetCriteria.maxTweets = int(maxtweets)
				
		outputFile = codecs.open(outputFileName, "w+", "utf-8")

		outputFile.write('username;date;retweets;favorites;text;geo;mentions;hashtags;id;permalink')

		print('Searching...\n')

		def receiveBuffer(tweets):
			for t in tweets:
				outputFile.write(('\n%s;%s;%d;%d;"%s";%s;%s;%s;"%s";%s' % (t.username, t.date.strftime("%Y-%m-%d %H:%M"), t.retweets, t.favorites, t.text, t.geo, t.mentions, t.hashtags, t.id, t.permalink)))
			outputFile.flush();
			print('More %d saved on file...\n' % len(tweets))

		got.manager.TweetManager.getTweets(tweetCriteria, receiveBuffer)

	except :
		print('Error!')
	finally:
		outputFile.close()
		print('Done. Output file generated "%s".' % outputFileName)

if __name__ == '__main__':
	exporter('Christmas','2016-11-24','2016-12-26',1000)
