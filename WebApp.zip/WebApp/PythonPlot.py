import matplotlib.pyplot as plt
import csv
with open('Signal_all.csv', 'r') as f:
  reader = csv.reader(f)
  your_list = list(reader)

print(your_list)

plt.plot(reader, 'ro')
plt.show()